﻿@echo off
chcp 65001 >nul
if /i "%~1"=="run" goto RUN
copy /y "%~f0" "%TEMP%\mah-uninstall-%RANDOM%.cmd" >nul
for %%F in ("%TEMP%\mah-uninstall-*.cmd") do set "SELF=%%~fF"
start "" /min "%COMSPEC%" /c ""%SELF%" run"
exit /b

:RUN
set "APPDIR=%LOCALAPPDATA%\MahLeMah"
set "SM=%APPDATA%\Microsoft\Windows\Start Menu\Programs\MahLeMah"
echo 正在卸载 MahLeMah v2.0.0 ...
if exist "%SM%\" rmdir /s /q "%SM%"
if exist "%APPDIR%\" rmdir /s /q "%APPDIR%"
echo MahLeMah v2.0.0 已卸载完成。
timeout /t 2 >nul

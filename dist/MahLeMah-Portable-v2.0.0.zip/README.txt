﻿Mah 了个 Mah v2.0.0 —— Windows 绿色安装版（单文件网页版）
================================================================

【重要说明】
  本机沙箱阻止执行新链接出的原生 PE（32 位 makensis.exe、GNU proc-macro DLL
  均被「拒绝访问」），因此本安装包内含的是**单文件网页版**，不是 Tauri exe。
  它同样完全离线可玩：所有 JS / CSS 都内联在 MahLeMah.html 里，无外部请求。
  在装有 Visual Studio 2022 C++ 生成工具的机器上执行 `npm run build:desktop`
  可产出原生 Tauri exe，再运行 `python tools/make_release.py` 重新打包即可。

【运行】开始菜单 → MahLeMah →「Mah 了个 Mah」，或双击安装目录里的
       Play-MahLeMah.cmd（用 Edge/Chrome 无边框窗口打开 MahLeMah.html）。
【存档】保存在浏览器的 localStorage 中，卸载时不会残留系统级数据。
【卸载】开始菜单 → MahLeMah →「卸载 MahLeMah」，或运行安装目录里的
       「卸载 MahLeMah.cmd」。卸载程序删除安装目录与快捷方式。

【玩法】点击未被遮挡的牌 → 进入底部 7 格槽位 → 三张相同 200ms 后自动消除。
       第 1 关：48 张 / 16 种牌型 / 3 层；第 2 关：240 张 / 16 种牌型 /
       15 个全局堆叠层（主堆 + 左右盲盒 + 底部保留区），多区域交叉遮挡。
       道具各 3 次：洗牌 / 撤销 / 移出 3 张；每局 1 次复活。

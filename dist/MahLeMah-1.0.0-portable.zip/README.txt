【注意：本包为单文件网页版】
  当前压缩包里没有 MahLeMah.exe（本机没有 MSVC 生成工具，且安全策略会拦截
  Rust 构建脚本的执行，无法在本机产出原生 exe）。
  请双击 MahLeMah.html，用浏览器（Edge / Chrome / Firefox）打开即可游玩，
  存档保存在该浏览器的 localStorage 中。
  需要 Windows 原生绿色 exe 时，在装有 Visual Studio 2022 C++ 生成工具的
  机器上执行：npm install && npm run build，产物为
  src-tauri\target\release\MahLeMah.exe（单文件、无需安装）。
  再执行 python tools/make_release.py 即可重新生成本压缩包。

================================================

Mah了个Mah —— 堆叠卡牌三消（绿色单文件版）
================================================

【运行】
  双击 MahLeMah.exe 即可，没有安装向导、不写注册表、不需要管理员权限。
  Windows 11 自带 WebView2 运行时；Windows 10 若缺失，程序会提示并打开
  微软官方下载页。

【数据位置】
  首次启动时，在 exe 同级目录创建 MahLeMah_Data 文件夹：
    MahLeMah_Data\save.json   存档
    MahLeMah_Data\webview\    WebView2 缓存
  不写 %APPDATA%、不写 %LOCALAPPDATA%、不写注册表。
  想换机器玩，把 exe 和 MahLeMah_Data 一起拷走即可。

【卸载】
  方式一（推荐）：进入游戏 → 标题页或暂停面板 → 「卸载并删除数据」→
                  二次确认「确定要彻底删除本游戏及所有存档吗？」→
                  程序会删除 MahLeMah_Data、退出，并在退出后删除 exe 自身。
  方式二：直接删除 MahLeMah.exe 和 MahLeMah_Data 文件夹，系统里不留任何痕迹。

【玩法】
  点击没有被压住的牌 → 进入底部 7 格槽位 → 三张相同自动消除。
  槽位放满且无法消除即失败；清空牌桌即通关。

  第 1 关：18 张 / 2 层 / 6 种牌型，教学关，正常玩必过（10 秒）。
           牌面尺寸与第 2 关完全一致（90 x 104），不会放大。
  第 2 关：225 张 / 7 层 / 15 种牌型，纯随机发牌，允许天然死局。
           开局可点由堆叠自然决定（顶层 10 张左右，不设上下限）；
           被压住的牌最多露出约 30% 面积。

  道具（第 2 关各 3 次）：洗牌 / 撤销 / 移出 3 张。
  复活（每局 1 次）：清空槽位，不赠送额外道具。

【运行环境】
  Windows 10 1809+ / Windows 11（x64）。完全离线，无外部图片、字体、
  音频文件与服务器依赖。
